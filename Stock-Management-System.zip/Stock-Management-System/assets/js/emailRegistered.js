function emailAlert() {
    alert("Email has already been registered. Please use a different email.");
    
    window.location.href = "signUp.php";
}

