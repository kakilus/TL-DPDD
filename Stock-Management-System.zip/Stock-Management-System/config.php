<?php session_start(); ?>
<?php
$websiteName = "Stock Management System";
$host = "localhost";
$user = "root";
$password = "";
$database = "stock_management_system";
?>